<template>
  <!-- <img alt="Vue logo" src="./assets/logo.png"> -->
  <Cabecera></Cabecera>
  <navegador></navegador>
  <router-view></router-view>
  <!-- <cartelera></cartelera> -->
  <!-- <inicio></inicio> -->
  <pie></pie>
  <!-- <router-view></router-view>
  <Center></Center>
  <Footer></Footer> --> 



</template>

<script>

import Cabecera from './components/Cabecera.vue'
import navegador from './components/navegador.vue'
// import cartelera from './components/cartelera.vue'
import pie from './components/pie.vue'
// import inicio from './components/inicio.vue'

// import ej1 from './components/ej1.vue'
// import Slider from './components/slider.vue'
// import Center from './components/center.vue'
// import Footer from './components/Footer.vue'

export default {
  name: 'App',
  components: {
  Cabecera,
  navegador,
  // cartelera,
  // inicio,
  pie
  // Slider,
  // Center,
  // Footer
  }
}
</script>

<!-- 
// <script>
// export default {
//   name: 'App',
//   data(){
//     return{
//       edad:'',
//       peliculas:[
//         {title:'La Guerra de las Galaxias', year:2018, image:"https://cmonmurcia.com/wp-content/uploads/2017/12/guerra-galaxias-episodio-vii-despertar-fuerza_2.jpg"},
//         {title:'Rocky', year:1984, image:"https://www.diariodesevilla.es/2019/01/24/sociedad/Rocky-soberano-Ivan-Drago-IV_1321678183_104812123_1200x675.jpg"},
//         {title:'El Padrino', year:1975, image:"https://d9zuehkdkxba0.cloudfront.net/wp-content/uploads/2016/04/El-Padrino-RadioHouse.jpg"},
//         {title:'Spiderman', year:2012, image:"https://es.web.img2.acsta.net/pictures/21/12/01/12/07/0243323.jpg"},
//         'La Guerra de las Galaxias','Rocky','El Padrino','Spiderman']
//     }
//   }
// }
// </script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
} -->
<!-- </style> -->
<!-- <template>

</template>

<script>



</script> -->