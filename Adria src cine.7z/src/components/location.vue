<template>
<!-- <p>location is here:</p> -->
  <iframe id="image" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3573.715562193588!2d1.203540760983715!3d41.131805738795244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf2a54e178dc2491!2sLes%20Gavarres!5e0!3m2!1sen!2ses!4v1645015044453!5m2!1sen!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

</template>

<script>
export default {
  name: 'location',
  
}
</script>


<style scoped>
#image{
  justify-content: center;
  width:100%;
}
/* h3 {
  margin: 40px 0 0;
}
.imagen{
  width: 100%;
}
a {
  color: #42b983;
} */
</style>
