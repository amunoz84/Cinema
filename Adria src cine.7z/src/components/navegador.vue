<template>
    <header id="header">
            <div class="center">
                 <nav id="menu">
                    
                        <div id="box1">
                            <h1><router-link to="/inicio" active-class="active">Cinema Theater</router-link></h1>
                        </div>
                        <div id="box2">
                            <h1><router-link to="/cartelera" active-class="active">Cinema Listings</router-link></h1>
                        </div>
                        <div id="box3">
                            <h1><router-link to="/location" active-class="active">Location</router-link></h1>
                        </div>
                                        
                    
                </nav>

                <!--LIMPIAR FLOTADOS-->
                <div class="clearfix"></div>
            </div>
        </header>
</template>

<script>
export default {
  name: 'navegador',
}
</script>


<style scoped>
#menu {
  background-color: red;
  text-align: center;
  padding: 20px;
  margin-bottom: 0px;
  margin-top:0px;
  display: flex;
  justify-content: space-evenly;
}
#box1{
  padding:50px;
}
#box2{
  padding:50px;
}
#box3{
  padding:50px;
}
a {
  color: black;
}
</style>
