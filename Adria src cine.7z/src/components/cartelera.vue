<template>
<div>
  <ul>
    <div>
  <li style="list-style:none" v-for="pelicula in peliculas1" :key="pelicula">
    <img class="cartelera" style="max-width:67%; max-height:67%;" :src="pelicula.image" :alt="pelicula.title" :title="pelicula.title">
    <h1 class="title">{{pelicula.title}}</h1>
    <p class="plot">{{pelicula.plot}}</p>
    <a class="trailer" :href=pelicula.trailer target=_blank> Watch trailer</a>
  </li>
  </div>
  <br>
  <div>
  <li style="list-style:none" v-for="pelicula in peliculas2" :key="pelicula">
    <img class="cartelera" style="max-width:67%; max-height:67%;" :src="pelicula.image" :alt="pelicula.title" :title="pelicula.title">
    <h1 class="title">{{pelicula.title}}</h1>
    <p class="plot">{{pelicula.plot}}</p>
    <a class="trailer" :href=pelicula.trailer target=_blank> Watch trailer</a>
  </li>
  </div>
  </ul>
</div>
</template>

<script>


export default {
  name: 'cartelera',
  data(){
    return{
      peliculas1:[
        {title:'Star Wars', plot: 'Thirty years after the Galactic Civil War, the First Order has risen from the fallen Galactic Empire and seeks to end the New Republic. The Resistance, backed by the Republic and led by General Leia Organa, opposes the First Order. Leia searches for her brother, Luke Skywalker, who has gone missing.', year:2018, image:"https://cmonmurcia.com/wp-content/uploads/2017/12/guerra-galaxias-episodio-vii-despertar-fuerza_2.jpg", trailer:"https://www.youtube.com/watch?v=sGbxmsDFVnE"},
        {title:'Rocky', year:1984, plot:'Having become the world heavyweight champion, former working-class boxer Rocky Balboa (Sylvester Stallone) is rich and famous beyond his wildest dreams, which has made him lazy and overconfident. In a double whammy, he loses his trainer and father figure Mickey (Burgess Meredith) and then has his title stolen by the arrogant, menacing challenger Clubber Lang (Mr. T). Turning to his former adversary, Apollo Creed (Carl Weathers), for help, Rocky struggles to get his old fire back.', image:"https://www.ecartelera.com/carteles/5100/5146/001_m.jpg", trailer:"https://www.youtube.com/watch?v=7RYpJAUMo2M"},
        {title:'The Godfather', year:1975, plot:"In 1945 New York City, at his daughter Connie's wedding to Carlo, Vito Corleone, the Don of the Corleone crime family listens to requests. His youngest son, Michael, who was a Marine during World War II, introduces his girlfriend, Kay Adams, to his family at the reception. Johnny Fontane, a popular singer and Vito's godson, seeks Vito's help in securing a movie role; Vito dispatches his consigliere, Tom Hagen, to Los Angeles to persuade studio head Jack Woltz to give Johnny the part. Woltz refuses until he wakes up in bed with the severed head of his prized stallion.", image:"https://d9zuehkdkxba0.cloudfront.net/wp-content/uploads/2016/04/El-Padrino-RadioHouse.jpg", trailer:"https://www.youtube.com/watch?v=UaVTIH8mujA"},
      ],
      peliculas2:[
        {title:'King Richard', year:2012, plot:"Armed with a clear vision and a brazen, 78-page plan, Richard Williams is determined to write his two daughters, Venus and Serena, into history. Training on tennis courts in Compton, Calif., Richard shapes the girls' unyielding commitment and keen intuition. Together, the Williams family defies seemingly insurmountable odds and the prevailing expectations laid before them.", image:"https://m.media-amazon.com/images/M/MV5BYTcyNmY4ZGEtYmE4Zi00ZDViLTlmYzMtMmQ4ZTM4OWNmZjQxXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_.jpg", trailer:"https://www.youtube.com/watch?v=BKP_0z52ZAw"},
        {title:'Valerian and the City of a Thousand Planets', year:2017, plot:"In the 28th century, special operatives Valerian (Dane DeHaan) and Laureline work together to maintain order throughout the human territories. Under assignment from the minister of defense, the duo embarks on a mission to Alpha, an ever-expanding metropolis where diverse species gather to share knowledge and culture. When a dark force threatens the peaceful city, Valerian and Laureline must race against time to identify the menace that also jeopardizes the future of the universe.", image:"https://i.scdn.co/image/ab67616d0000b273e3d66ffaf1c6e1dda6558df4", trailer:"https://www.youtube.com/watch?v=cPeqNTqZNN0"},
        {title:'Pocahontas', year:1995, plot:"This is the Disney animated tale of the romance between a young American Indian woman named Pocahontas (Seong Yujin) and Capt. John Smith (Lee Jeong-gu), who journeyed to the New World with other settlers to begin fresh lives. Her powerful father, Chief Powhatan, disapproves of their relationship and wants her to marry a native warrior. Meanwhile, Smith's fellow Englishmen hope to rob the Native Americans of their gold. Can Pocahontas' love for Smith save the day?", image:"https://static.miraheze.org/greatestmovieswiki/0/0a/7D5B97AB-047C-4D10-AF4B-4E1EDDED8460.jpeg", trailer:"https://www.youtube.com/watch?v=5iB82S8rHyg"},
        // 'Star Wars','Rocky','Godfather','King Richard', 'Valerian and the City of a Thousand Planets','Pocahontas' 
      ]
      
    }
  }
}
</script>



<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
ul {
  list-style-type: none;
  padding: 0;
  background-color: black;
  display: flex;
  justify-content: space-between;
  margin-top: 0px;
  margin-bottom: 0px;
  /* flex-wrap: wrap; */
}
li {
  /* display: inline-block; */
  margin: 10px;
  color:white;
}
a {
  color: #42b983;
}
.plot{
  text-align: justify;
  text-justify: inter-word;

}
.trailer{
  text-align: justify;
  text-justify: inter-word;
  margin-bottom: 200px;
  margin-left: 10px;
}
.title{
  text-align: center;
}
.cartelera{
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}
</style>
