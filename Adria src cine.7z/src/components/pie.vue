<template>
    <header id="header">
            <div class="center">
              <a href="www.linkedin.com/in/adriamunozpallerola" target="_blanck"><img src="https://cdn.pixabay.com/photo/2021/02/08/15/44/social-media-5995266_960_720.png"></a>
              <p>&copy;Adria Munoz Pallerola</p>
                <!--LIMPIAR FLOTADOS-->
                <div class="clearfix"></div>
            </div>
        </header>
</template>

<script>
export default {
  name: 'pie',
}
</script>


<style scoped>
.center{
  color: white;
  background-color: black;
  text-align: center;
  padding-bottom: 40px;
}
img{
  height: 100px;
}
a {
  color: #42b983;
}
</style>
