<template>
<div>
  <li style="list-style:none" v-for="pelicula in peliculas" :key="pelicula">
    <div id="flex">
    <img style="width: 343%;" :src="pelicula.image" :alt="peliculas.title">
    </div>
  </li>
</div>
</template>

<script>
export default {
  name: 'Cabecera',
  data(){
    return{
        peliculas:[
        {title:'Ocine', image:"https://www.cineytele.com/wp-content/uploads/2020/08/ocine_plaza_eboli.jpg"}
        ]
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#flex{
margin-top: 0px;
  margin-bottom: -4px;
}
li {
  padding-top: 0px;
  display: inline-block;
  
}
a {
  color: #42b983;
}
</style>
