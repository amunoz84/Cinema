<template>

  
<img src="https://www.firstuunash.org/wp-content/uploads/2019/11/movie-theatre.jpg" alt="SalaCine" class="imagen">
    
</template>

<script>
export default {
  name: 'inicio',
  
}
</script>


<style scoped>
h3 {
  margin: 40px 0 0;
}
.imagen{
  width: 100%;
}
a {
  color: #42b983;
}
</style>
