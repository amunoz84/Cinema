import {createWebHistory, createRouter} from "vue-router"
import cabecera from '@/components/Cabecera.vue'
import navegador from '@/components/navegador.vue'
import cartelera from '@/components/cartelera.vue'
import pie from '@/components/pie.vue'
import inicio from '@/components/inicio.vue'
import location from '@/components/location.vue'
const routes=[
    {
        path:"/navegador",
        name:"navegador",
        component:navegador
    },
    {
        path:"/cabecera",
        name:"cabecera",
        component:cabecera
    },
    {
        path:"/cartelera",
        name:"cartelera",
        component:cartelera
    },
    {
        path:"/inicio",
        name:"inicio",
        component:inicio
    },
    {
        path:"/pie",
        name:"pie",
        component:pie
    },
    {
        path:"/location",
        name:"location",
        component:location
    },

]


const router=createRouter({
    history:createWebHistory(),
    routes,//routes:routes
});

export default router;